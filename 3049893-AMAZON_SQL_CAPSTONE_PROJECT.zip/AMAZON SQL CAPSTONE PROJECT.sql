
-- Data Wrangling: This is the first step where inspection of data is done to make sure
-- NULL values and missing values are detected and data replacement methods are used 
-- to replace missing or NULL values.
-- 1.1          Build a database
-- 1.2          Create a table and insert the data.
-- 1.3          Select columns with null values in them. There are no null values in our database as in creating the tables, we set NOT  NULL for each field, hence null values are filtered out.
SELECT * FROM amazondata.amazon;
SELECT *
FROM amazondata.amazon
WHERE "Invoice ID" IS NULL
   OR Branch IS NULL
   OR City IS NULL
   OR "Customer type" IS NULL
   OR Gender IS NULL
   OR "Product line" IS NULL
   OR "Unit price" IS NULL
   OR Quantity IS NULL
   OR "Tax 5%" IS NULL
   OR Total IS NULL
   OR date IS NULL
   OR time IS NULL
   OR "Payment" IS NULL
   OR cogs IS NULL
   OR "gross margin percentage" IS NULL
   OR "gross income" IS NULL
   OR "Rating" IS NULL;
 
 
-- Feature Engineering: This will help us generate some new columns from existing ones.
-- 2.1           Add a new column named timeofday to give insight of sales in the Morning, Afternoon and Evening. This will help answer the question on which part of the day most sales are made.
-- 2.2          Add a new column named dayname that contains the extracted days of the week on which the given transaction took place (Mon, Tue, Wed, Thur, Fri). This will help answer the question on which week of the day each branch is busiest.
-- 2.3        Add a new column named monthname that contains the extracted months of the year on which the given transaction took place (Jan, Feb, Mar). Help determine which month of the year has the most sales and profit.
   
   ALTER TABLE amazon ADD COLUMN timeofday VARCHAR(10);
   UPDATE amazondata.amazon
      SET timeofday = CASE
    WHEN time(time) >= "00:00:00" AND time(time) < "12:00:00" THEN 'Morning'
    WHEN time(time) >= "12:00:00" AND time(time) < "18:00:00" THEN 'Afternoon'
    ELSE 'Evening'
END;

   
   ALTER TABLE amazon ADD COLUMN dayname VARCHAR(10);
   update amazondata.amazon
    SET dayname = CASE dayofweek(date)
    When 1 then 'Mon'
    When 2 then 'Tue'
    When 3 then 'Wed'
    When 4 then 'Thur'
    When 5 then 'Fri'
    When 6 then 'Sat'
    When 7 then 'Sun'
end ;
    
ALTER TABLE amazon ADD COLUMN monthname VARCHAR(10);
update amazondata.amazon
SET monthname = CASE month(date)
When 1 then 'Jan'
When 2 then 'Feb'
When 3 then 'Mar'
When 4 then 'Apr'
When 5 then 'May'
When 6 then 'Jun'
When 7 then 'Jul'
When 8 then 'Aug'
When 9 then 'Sep'
When 10 then 'Oct'
When 11 then 'Nov'
When 12 then 'Dec'
end;

    
-- Exploratory Data Analysis (EDA): Exploratory data analysis is done to answer the listed questions and aims of this project.
-- Business Questions To Answer:

-- 1.What is the count of distinct cities in the dataset?
select count(distinct City) from amazondata.amazon;

-- 2.For each branch, what is the corresponding city?
select distinct Branch , City from amazondata.amazon;

-- 3.What is the count of distinct product lines in the dataset?
SELECT COUNT(DISTINCT `Product line`) 
FROM amazondata.amazon;

-- 4.Which payment method occurs most frequently?
select Payment, count(*) as Frequently
from amazondata.amazon
group by Payment
order by Frequently Desc
limit 1;

-- 5. Which product line has the highest sales?
select `Product line` , count(*) as total_sales
from amazondata.amazon
group by `Product line`
order by total_sales
desc;

-- 6.How much revenue is generated each month?
select monthname,sum(Total) as revenue
from amazondata.amazon
group by monthname
order by revenue desc;

-- 7.In which month did the cost of goods sold reach its peak?
select monthname,sum(cogs) as total_cost
from amazondata.amazon
group by monthname
order by total_cost desc;

-- 8.Which product line generated the highest revenue?
select `Product line`,sum(Total) as high_revenue
from amazondata.amazon
group by `Product line`
order by high_revenue desc;

-- 9.In which city was the highest revenue recorded? 
select City , sum(Total) as highest_revenue
from amazondata.amazon
group by City
order by highest_revenue desc;

-- 10.Which product line incurred the highest Value Added Tax?
select `Product line`, sum(`Tax 5%`) as high_value
from amazondata.amazon
group by `Product line`
order by high_value desc;


-- 11.For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."
select `Product line` , sum(Total) as total_sales,
 CASE
when sum(Total) > (SELECT AVG(total_sales) FROM 
(
select `Product line`,sum(Total) as total_sales
from amazondata.amazon
group by `Product line`
)   as subquery
) THEN 'GOOD'
ELSE 'BAD'
END AS sales
FROM amazondata.amazon
GROUP BY `Product line`
order by total_sales desc
limit 0,1000;


-- 12.Identify the branch that exceeded the average number of products sold.
  select Branch , sum(Quantity) as total_quantity
  from amazondata.amazon
  group by Branch
  having sum(Quantity) >(select avg(Quantity) from amazondata.amazon);
  
-- 13.Which product line is most frequently associated with each gender?
select `Product line`, Gender , count(*) as frequently
from amazondata.amazon
group by `Product line`,Gender
order by frequently desc;

-- 14.Calculate the average rating for each product line.
select `Product line`,avg(Rating) as avg_rating from amazondata.amazon
group by `Product line`
order by avg_rating desc;

-- 15. Count the sales occurrences for each time of day on every weekday.
select timeofday, dayname,count(*) as sales_occur
from amazondata.amazon
where dayname in('Mon','Tue','Wed','Thur','Fri','Sat','Sun')
group by timeofday, dayname
order by sales_occur desc;

-- 16.Identify the customer type contributing the highest revenue.
select `Customer type`, sum(total) as highest_revenue
from amazondata.amazon
group by `Customer type`
order by highest_revenue desc;

-- 17.Determine the city with the highest VAT percentage.
select City,sum(`Tax 5%`) as high_tax , sum(Total) as high_total , (sum(`Tax 5%`)/sum(Total)) * 100 as vat_percent
from amazondata.amazon
group by City
order by vat_percent desc
limit 3;

-- 18.Identify the customer type with the highest VAT payments.
select `Customer type`,sum(`Tax 5%`) as high_vat
from amazondata.amazon
group by `Customer type`
order by high_vat desc;

--  19. What is the count of distinct customer types in the dataset?
select count(distinct (`Customer type`)) as dist_cust from amazondata.amazon;

-- 20.What is the count of distinct payment methods in the dataset?

-- 21.Which customer type occurs most frequently?
select `Customer type` , count(`Customer type`) as frequently
from amazondata.amazon
group by `Customer type`
order by frequently desc;

-- 22.Identify the customer type with the highest purchase frequency.
select `Customer type` , count(*) as high_purchase
from amazondata.amazon
group by `Customer type`
order by high_purchase desc limit 1;

-- 23.Determine the predominant gender among customers.
select Gender, count(*) as predominant_gender
from amazondata.amazon
group by Gender
order by predominant_gender desc limit 1;

-- 24.Examine the distribution of genders within each branch.
select Gender,Branch,count(*) as distrubution
from amazondata.amazon
group by Gender,Branch
order by distrubution desc;

-- 25.Identify the time of day when customers provide the most ratings.
select timeofday,count(Rating) as count_rating
from amazondata.amazon
group by timeofday
order by count_rating desc;

-- 26.Determine the time of day with the highest customer ratings for each branch.
select Branch,timeofday,avg(Rating) as avg_rating
from amazondata.amazon
group by Branch,timeofday
order by avg_rating desc;

-- 27.Identify the day of the week with the highest average ratings.
select dayname,avg(Rating) as avg_rating
from amazondata.amazon
group by dayname
order by avg_rating desc;

-- 28.Determine the day of the week with the highest average ratings for each branch.
select dayname,Branch,avg(Rating) as avg_rating
from amazondata.amazon
group by dayname,Branch
order by avg_rating desc;
    
  

